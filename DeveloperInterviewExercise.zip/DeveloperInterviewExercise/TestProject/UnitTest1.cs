using FileData;
using NUnit.Framework;

namespace TestProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GettingFileVersion_CheckType()
        {
            FileProcessor fp = new FileProcessor();
            string fileName = "test";
            var result = fp.getFileVersion(fileName);            
            Assert.That(result, Is.TypeOf<string>());
        }
        [Test]
        public void GettingFileSize_CheckType()
        {
            FileProcessor fp = new FileProcessor();
            string fileName = "test";
            var result = fp.getFileSize(fileName);            
            Assert.That(result, Is.TypeOf<int>());
        }

        [Test]
        public void ProcessinputForVersion_CheckSuccessReturn()
        {
            var input = "-v C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsTrue(result);
        }

        [Test]
        public void ProcessinputForSize_CheckSuccessReturn()
        {
            var input = "-s C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsTrue(result);
        }

        [Test]
        public void ProcessinputOtherForVersion_CheckSuccessReturn()
        {
            var input = "--version C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsTrue(result);
        }

        [Test]
        public void ProcessinputOtherForSize_CheckSuccessReturn()
        {
            var input = "--size C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsTrue(result);
        }

        [Test]
        public void ProcessinputForVersion_CheckFailureReturn()
        {
            var input = "-/v C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsFalse(result);
        }

        [Test]
        public void ProcessinputForSize_CheckFailureReturn()
        {
            var input = "/-s C:/test.txt";
            var result = Program.processInput(input);
            Assert.IsFalse(result);
        }
    }
}