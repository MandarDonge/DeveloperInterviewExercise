﻿using FileData.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {           
            try
            {
                Console.Write("Please enter input: ");
                string val = Console.ReadLine();
                var result = processInput(val);
                if (result == false)
                {
                    Console.WriteLine("Please enter Valid input!");
                }
                Console.ReadLine();
            }
            catch (Exception)
            {
                throw;
            }
        }


        public static bool processInput(string input)
        {
            bool isSuccess = false;
            try
            {
                var splittedArray = input.Split(' ');
                if (splittedArray != null && splittedArray.Length > 0)
                {
                    if (Constants.versionArgument.Contains(splittedArray[0].ToLower()))
                    {
                        if (splittedArray[1] != null && splittedArray[1] != "")
                        {
                            FileProcessor fp = new FileProcessor();
                            Console.WriteLine(fp.getFileVersion(splittedArray[1]));
                            isSuccess = true;
                        }
                    }
                    else if (Constants.sizeArgument.Contains(splittedArray[0].ToLower()))
                    {
                        if (splittedArray[1] != null && splittedArray[1] != "")
                        {
                            FileProcessor fp = new FileProcessor();
                            Console.WriteLine(fp.getFileSize(splittedArray[1]));
                            isSuccess = true;
                        }
                    }
                }
                return isSuccess;
            }
            catch (Exception)
            {
                return isSuccess;
            }
            
        }
    }
}
