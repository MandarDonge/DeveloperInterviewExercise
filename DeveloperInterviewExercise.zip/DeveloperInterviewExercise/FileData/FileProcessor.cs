﻿using FileData.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    public class FileProcessor
    {        
        public string getFileVersion(string fileName)
        {
            FileDetails fd = new FileDetails();           
            return fd.Version(fileName);
        }

        public int getFileSize(string fileName)
        {
            FileDetails fd = new FileDetails();
            return fd.Size(fileName);
        }
    }
}
