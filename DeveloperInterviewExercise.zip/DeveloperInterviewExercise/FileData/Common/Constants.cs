﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileData.Common
{
    public class Constants
    {
        public static readonly string[] versionArgument = { "-v", "--v", "/v", "--version" };
        public static readonly string[] sizeArgument = { "-s", "--s", "/s", "--size" };
    }

    public enum FileDetailType
    {
        Version = 1,
        Size = 2
    }
}
